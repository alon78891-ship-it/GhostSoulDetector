import math
import random

from kivy.lang import Builder
from kivy.clock import Clock
from kivy.properties import StringProperty, NumericProperty, BooleanProperty
from kivymd.app import MDApp
from kivymd.uix.screenmanager import MDScreenManager
from kivymd.uix.screen import MDScreen

try:
    from plyer import compass
except Exception:
    compass = None

KV = r"""
MDScreenManager:
    MainDashboard:
    JainSection:

<MainDashboard>:
    name: "dashboard"
    MDBoxLayout:
        orientation: "vertical"
        md_bg_color: 0.04, 0.01, 0.01, 1

        MDTopAppBar:
            title: app.translations[app.current_lang]["title"]
            anchor_title: "center"
            md_bg_color: 0.75, 0.0, 0.0, 1
            right_action_items: [["translate", lambda x: app.change_language()]]

        ScrollView:
            MDBoxLayout:
                orientation: "vertical"
                padding: "18dp"
                spacing: "18dp"
                adaptive_height: True

                MDLabel:
                    text: app.translations[app.current_lang]["radar_sec"]
                    font_style: "H6"
                    theme_text_color: "Custom"
                    text_color: 1, 0.1, 0.1, 1
                    bold: True
                    adaptive_height: True

                Widget:
                    id: radar_widget
                    size_hint_y: None
                    height: "200dp"
                    canvas:
                        Color:
                            rgba: 0.25, 0.0, 0.0, 1
                        Line:
                            circle: (self.center_x, self.center_y, dp(90))
                            width: 1.5
                        Line:
                            circle: (self.center_x, self.center_y, dp(50))
                            width: 1
                        Line:
                            points: [self.center_x - dp(90), self.center_y, self.center_x + dp(90), self.center_y]
                        Line:
                            points: [self.center_x, self.center_y - dp(90), self.center_x, self.center_y + dp(90)]

                MDCard:
                    orientation: "vertical"
                    padding: "15dp"
                    spacing: "8dp"
                    adaptive_height: True
                    md_bg_color: 0.1, 0.03, 0.03, 1
                    radius: [8, 8, 8, 8]

                    MDLabel:
                        text: "📡 Offline magnetic field: " + str(round(root.emf_val, 2)) + " µT"
                        theme_text_color: "Custom"
                        text_color: 1, 0.4, 0.4, 1
                        bold: True
                        adaptive_height: True

                    MDLabel:
                        text: "📊 Relative signal indicator: " + str(root.energy_val) + "%"
                        theme_text_color: "Secondary"
                        adaptive_height: True

                    MDLabel:
                        text: "🔴 Status: " + root.alert_status
                        theme_text_color: "Custom"
                        text_color: (1, 0.2, 0.2, 1) if "⚠️" in root.alert_status else (0.4, 0.8, 0.4, 1)
                        adaptive_height: True

                    MDLabel:
                        text: "Sensor data is not evidence of ghosts, spirits, or paranormal activity."
                        theme_text_color: "Secondary"
                        adaptive_height: True

                MDRaisedButton:
                    text: "STOP SCAN" if root.scanning else "START OFFLINE SENSOR SCAN"
                    md_bg_color: 0.8, 0, 0, 1
                    size_hint_x: 1
                    on_release: root.toggle_radar()
                    adaptive_height: True

                MDRectangleFlatIconButton:
                    icon: "lotus"
                    text: app.translations[app.current_lang]["jain_sec"]
                    theme_text_color: "Custom"
                    text_color: 1, 0.7, 0.3, 1
                    line_color: 1, 0.5, 0.2, 1
                    size_hint_x: 1
                    on_release: app.root.current = "jain"

<JainSection>:
    name: "jain"
    MDBoxLayout:
        orientation: "vertical"
        md_bg_color: 0.02, 0.02, 0.04, 1

        MDTopAppBar:
            title: app.translations[app.current_lang]["jain_sec"]
            anchor_title: "center"
            md_bg_color: 0.05, 0.35, 0.25, 1
            left_action_items: [["arrow-left", lambda x: app.go_back()]]

        ScrollView:
            MDBoxLayout:
                orientation: "vertical"
                padding: "20dp"
                spacing: "15dp"
                adaptive_height: True

                MDLabel:
                    text: "🪷 Local Soul & Aatma Archive"
                    font_style: "H5"
                    theme_text_color: "Custom"
                    text_color: 1, 0.7, 0.3, 1
                    bold: True
                    adaptive_height: True

                MDCard:
                    orientation: "vertical"
                    padding: "15dp"
                    spacing: "10dp"
                    adaptive_height: True
                    md_bg_color: 0.05, 0.08, 0.07, 1
                    radius: [8, 8, 8, 8]

                    MDLabel:
                        text: "Three Jewels (Ratnatraya)"
                        bold: True
                        theme_text_color: "Custom"
                        text_color: 0.2, 0.8, 0.5, 1
                        adaptive_height: True

                    MDLabel:
                        text: "• Samyak Darshana (Right Faith)\\n• Samyak Jnana (Right Knowledge)\\n• Samyak Charitra (Right Conduct)\\n\\nJain tradition teaches these as principles for spiritual development."
                        theme_text_color: "Secondary"
                        adaptive_height: True
"""


class MainDashboard(MDScreen):
    emf_val = NumericProperty(0.0)
    energy_val = NumericProperty(0)
    alert_status = StringProperty("Offline Standby")
    scanning = BooleanProperty(False)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.sweep_angle = 0
        self._scan_event = None
        self._sensor_enabled = False
        if compass:
            try:
                compass.enable()
                self._sensor_enabled = True
            except Exception:
                self._sensor_enabled = False

    def toggle_radar(self):
        if not self.scanning:
            self.scanning = True
            self.alert_status = "Scanning local sensor data"
            self._scan_event = Clock.schedule_interval(self.update_telemetry, 0.08)
        else:
            self.scanning = False
            self.alert_status = "Engine stopped"
            if self._scan_event:
                self._scan_event.cancel()
                self._scan_event = None
            self.ids.radar_widget.canvas.remove_group("dynamic_items")

    def update_telemetry(self, dt):
        # Plyer compass support varies by device. Fall back to an explicitly simulated
        # value when real sensor data is unavailable; never label it as real.
        field = None
        if compass and self._sensor_enabled:
            try:
                field = getattr(compass, "field", None)
                if field and len(field) >= 3:
                    self.emf_val = math.sqrt(sum(float(v) ** 2 for v in field[:3]))
                else:
                    field = None
            except Exception:
                field = None

        if field is None:
            self.emf_val = round(random.uniform(25.0, 55.0), 2)
            self.alert_status = "Demo signal (sensor unavailable)"
        elif self.emf_val > 70.0:
            self.alert_status = "⚠️ High magnetic reading"
        else:
            self.alert_status = "Sensor reading available"

        self.energy_val = min(100, int((self.emf_val / 90.0) * 100))
        widget = self.ids.radar_widget
        widget.canvas.remove_group("dynamic_items")
        self.sweep_angle = (self.sweep_angle + 6) % 360
        rad = math.radians(self.sweep_angle)
        x_end = widget.center_x + 90 * math.cos(rad)
        y_end = widget.center_y + 90 * math.sin(rad)
        with widget.canvas:
            from kivy.graphics import Color, Line, Ellipse
            Color(1, 0, 0, 0.7, group="dynamic_items")
            Line(points=[widget.center_x, widget.center_y, x_end, y_end],
                 width=2, group="dynamic_items")
            if self.emf_val > 70.0:
                Color(1, 1, 0, 1, group="dynamic_items")
                Ellipse(pos=(widget.center_x + random.randint(-50, 50),
                             widget.center_y + random.randint(-50, 50)),
                        size=(10, 10), group="dynamic_items")

    def on_leave(self, *args):
        if self._scan_event:
            self._scan_event.cancel()
            self._scan_event = None
        self.scanning = False


class JainSection(MDScreen):
    pass


class ParanormalSpiritualApp(MDApp):
    current_lang = StringProperty("en")

    def build(self):
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Red"
        self.translations = {
            "en": {"title": "MATRIX RADAR HUD", "radar_sec": "Offline Sensor Radar",
                   "jain_sec": "Jain Dharma & Soul Wisdom"},
            "hi": {"title": "मैट्रिक्स रडार डैशबोर्ड", "radar_sec": "ऑफलाइन सेंसर रडार",
                   "jain_sec": "जैन धर्म एवं आत्मा ज्ञान"},
            "bn": {"title": "ম্যাট্রিক্স রাডার ড্যাশবোর্ড", "radar_sec": "অফলাইন সেন্সর রাডার",
                   "jain_sec": "জৈন ধর্ম ও আত্মা তত্ত্ব"},
            "as": {"title": "মেট্ৰিক্স ৰাডাৰ ডেশ্ববৰ্ড", "radar_sec": "অফলাইন চেন্সৰ ৰাডাৰ",
                   "jain_sec": "জৈন ধৰ্ম আৰু আত্মা তত্ত্ব"}
        }
        self.lang_cycle = ["en", "hi", "bn", "as"]
        return Builder.load_string(KV)

    def change_language(self):
        idx = self.lang_cycle.index(self.current_lang)
        self.current_lang = self.lang_cycle[(idx + 1) % len(self.lang_cycle)]

    def go_back(self):
        self.root.current = "dashboard"


if __name__ == "__main__":
    ParanormalSpiritualApp().run()
