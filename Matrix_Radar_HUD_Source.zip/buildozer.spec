[app]
title = Matrix Radar HUD
package.name = matrixradarhud
package.domain = org.offlineradar
source.dir = .
source.include_exts = py,kv,png,jpg,atlas,txt
version = 1.0.0
requirements = python3,kivy==2.3.0,kivymd==1.2.0,plyer
orientation = portrait
fullscreen = 0
android.permissions = VIBRATE
android.api = 35
android.minapi = 23
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True
p4a.bootstrap = sdl2
