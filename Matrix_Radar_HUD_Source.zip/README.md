# Matrix Radar HUD (Offline Android project)

## Included
- Red cyberpunk radar HUD
- Start/stop scanning animation
- Offline magnetic-field display when supported
- Demo values clearly labelled when a sensor reading is unavailable
- English, Hindi, Bengali and Assamese UI labels
- Jain Dharma / Ratnatraya information screen
- Buildozer configuration for creating an Android APK

## Important accuracy note
This app cannot scientifically detect ghosts, spirits, souls, or negative energy.
A phone magnetic sensor measures magnetic fields, not paranormal activity. When
the required hardware/sensor reading is unavailable, the app shows demo values
and labels them as such.

## Build APK with GitHub Actions
1. Upload the contents of this ZIP to a GitHub repository.
2. Add a workflow using Buildozer, or build locally with Buildozer on Linux.
3. APK output is normally placed in `bin/`.

This is a source project ZIP, not a prebuilt APK.
